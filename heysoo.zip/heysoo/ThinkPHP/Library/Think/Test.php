<?php
class Test{
	public function Test(){
		echo 'It is a test!';
	}
}