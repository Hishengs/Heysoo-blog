<?php 
namespace Home\Model;
use Think\Model;
class DiaryModel extends Model {
}
?>