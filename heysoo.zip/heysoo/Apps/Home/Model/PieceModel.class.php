<?php 
namespace Home\Model;
use Think\Model;
class PieceModel extends Model {
}
?>