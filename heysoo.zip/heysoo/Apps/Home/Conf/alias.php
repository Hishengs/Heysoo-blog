<?php
return array(
		'Think\Test' => THINK_PATH.'Test.php'
);